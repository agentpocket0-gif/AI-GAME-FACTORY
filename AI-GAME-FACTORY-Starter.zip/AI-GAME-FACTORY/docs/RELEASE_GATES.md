# Release gates

A release candidate must provide evidence for every applicable item.

## Product
- [ ] Game Bible approved; core loop and target audience clear
- [ ] No placeholder UI, fake buttons, missing levels or unfinished flows
- [ ] Tutorial/onboarding and settings work
- [ ] Save/load and progression survive app restart
- [ ] Pause/resume, failure/retry and completion states work

## 3D / Audio
- [ ] Character models, rigs and animation transitions verified
- [ ] Environment collisions and navigation verified
- [ ] Materials, lighting and effects run on target hardware
- [ ] Audio controls and focus behavior work
- [ ] Asset manifest and licenses reviewed

## Engineering
- [ ] No parser/import errors
- [ ] Automated tests pass
- [ ] No critical/high bugs open
- [ ] Real Android device test completed
- [ ] Performance/memory/load-time results recorded
- [ ] Offline behavior and network failure behavior tested

## Android / Store
- [ ] Unique package/application ID
- [ ] Version code/name correct
- [ ] Release signing configured securely
- [ ] Permissions justified
- [ ] Privacy policy and Data safety information prepared where required
- [ ] Store graphics, screenshots and description prepared
- [ ] Target API and store policies checked at release time
- [ ] APK/AAB installs and launches on target devices

Do not call a game "complete" while any mandatory item is unchecked or unknown.
