# DeepSeek Harness setup (verify against the installed release)

Official project: https://github.com/deepseek-ai/deepseek-harness
Official overview: https://www.deepseek.com/harness/en/

DSH is open-source and plugin-based. Its architecture uses profiles/bundles and ordered Cordis patches. The available profiles include `web`, `headless`, `sdk`, `sdk-minimal`, and `acp`. Inspect the exact profile/config in the DSH version you install before writing a patch.

## Important: no guessed configuration

Provider IDs, model adapter fields, plugin package names, and headless prompt invocation can change. Do not paste guessed YAML into `cordis.patch.yml`. Instead:

1. Install the exact DSH release in a disposable runner.
2. Run its help command and inspect the shipped headless profile/config dump.
3. Configure NVIDIA NIM and Gemini through the supported model-provider UI/config for that release.
4. Confirm each model can complete a simple text request.
5. Confirm tool calling works for the selected model; OpenAI-compatible endpoints do not guarantee identical tool-call behavior.
6. Add only verified profile patches and plugin versions to this repository.
7. Run a harmless read-only test before granting write access to the workspace.

## Provider endpoints

NVIDIA NIM OpenAI-compatible base URL (use the exact endpoint documented by the selected NIM model):
`https://integrate.api.nvidia.com/v1`

Gemini OpenAI-compatible endpoint:
`https://generativelanguage.googleapis.com/v1beta/openai/`

Use GitHub Actions secrets named `NVIDIA_NIM_API_KEY` and `GEMINI_API_KEY`. Never echo environment variables, print secrets, or include them in artifacts/logs.

## Suggested role routing

- Research / summarization: Gemini model with suitable context and tool support.
- Code changes / debugging: NVIDIA NIM model with reliable coding and tool-call support.
- Independent review: a second model/provider.
- Optional Claude Code child agent: only if separately configured and authorized; it is not included in this free-by-default stack.

## GitHub Actions integration

The starter intentionally does not invoke an undocumented `dsh headless --prompt ...` command. After confirming the exact CLI syntax and provider config, add it to a dedicated workflow step. Keep the workflow `workflow_dispatch` only initially. Do not trigger autonomous write-capable agents from arbitrary public issues or pull requests.

## Public repository warning

Any DSH profile file committed here must contain placeholders only. Store credentials in GitHub Secrets or the DSH credential store on an ephemeral runner.
