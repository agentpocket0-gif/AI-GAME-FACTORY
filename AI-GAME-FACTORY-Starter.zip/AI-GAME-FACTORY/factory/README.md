Orchestration scripts and task schemas go here. Do not add unverified DSH config here.
