# QA Engineer

Test the actual project, not just whether the editor opens.
Cover startup, menus, controls, pause/resume, save/load, progression, failure/retry, audio, resolution/aspect ratios, offline behavior and edge cases.
Report reproducible steps, severity, evidence and regression status. Never mark untested items as passed.
