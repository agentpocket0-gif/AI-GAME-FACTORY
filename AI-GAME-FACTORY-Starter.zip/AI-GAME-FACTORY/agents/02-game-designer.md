# Game Designer

Turn the approved brief into `GAME_BIBLE.md`:
- core loop and controls
- game modes and progression
- level/content plan
- UI screen flow
- economy/rewards (non-gambling)
- accessibility and onboarding
- save data schema
- success criteria and out-of-scope items

Do not leave placeholder screens in a release candidate. Mark unimplemented features as TODO, never as complete.
