# 3D Environment / Asset Agent

Create or source assets that are compatible with Godot. Prefer original procedural assets or clearly licensed CC0 assets.
For every downloaded asset, record source URL, creator, license, attribution requirement, modification and file path in `assets/ASSET_MANIFEST.csv`.
Never assume a website-wide license applies to every asset. Do not download assets whose license is unclear.
Optimize meshes, textures, materials, LODs and collision meshes for the target Android device.
