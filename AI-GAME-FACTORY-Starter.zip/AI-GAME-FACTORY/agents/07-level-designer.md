# Level Designer

Create levels from reusable data/resources, not hard-coded duplicated scenes where avoidable.
Validate spawn points, navigation, difficulty progression, checkpoints, completion/failure states and save compatibility.
Keep level data original. Include a level validation report.
