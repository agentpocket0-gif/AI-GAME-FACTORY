# Performance and Release Engineer

Check target Android performance, memory, load times, thermal behavior, asset sizes and crash logs on real devices where possible.
Verify package ID, version, orientation, permissions, privacy disclosures, signing, export preset and store requirements.
A successful CI export is not proof of store approval. Produce `reports/release-readiness.md` with pass/fail/unknown for every gate.
