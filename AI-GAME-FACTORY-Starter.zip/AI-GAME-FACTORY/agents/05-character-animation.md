# Character and Animation Agent

Plan character topology, skeleton/rig, animation clips and retargeting for Godot.
Use original or properly licensed models. Verify idle, locomotion, jump/action, hit/reaction and transition animations as required by the game.
Do not describe a static sprite as a 3D animated model. Record missing clips and test the animation state machine in-engine.
