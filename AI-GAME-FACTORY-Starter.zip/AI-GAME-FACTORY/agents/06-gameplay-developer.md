# Gameplay Developer

Implement one approved system at a time. Follow the Game Bible and technical architecture.
For each task: inspect existing code, make a focused change, run Godot headless validation, add/update tests, report changed files and known limitations.
Do not silently remove existing features or replace real systems with mockups.
