# AI Game Factory

A public, GitHub Actions-first starter for AI-assisted Godot game production.

**Chosen stack**
- DeepSeek Harness (DSH) as the agent host/orchestrator
- NVIDIA NIM and Google Gemini as model providers
- Godot 4.7.2 stable as the game engine
- Blender Python for procedural asset work when needed
- GitHub Actions for CI, validation and Android export

> This repository is a starter framework, not a magic one-click AAA game generator. The DSH headless invocation and provider patch must be verified against the exact installed DSH release before enabling autonomous agent runs. This starter deliberately does not guess undocumented DSH config keys or CLI flags.

## First setup

1. Create a **Public** repository named `AI-GAME-FACTORY` in your GitHub account.
2. Upload/push the contents of this folder to its default branch.
3. In GitHub: **Settings → Secrets and variables → Actions → New repository secret**, add:
   - `NVIDIA_NIM_API_KEY`
   - `GEMINI_API_KEY`
4. Do not put API keys, signing keys, or personal tokens in files or Issues.
5. Open `docs/DSH_SETUP.md` and configure DSH against its current official docs.
6. Add a Godot project under `game/`. The starter contains a minimal project file.
7. Run **Actions → Godot CI → Run workflow**.

## How the workflows are intended to work

- `godot-ci.yml`: downloads the pinned Godot 4.7.2 editor, imports the project and runs headless validation.
- `android-export.yml`: manually triggered; requires a valid `export_presets.cfg`, Android export templates, Android SDK and signing secrets.
- `agent-request.yml`: creates a safe, auditable task record from a manual workflow dispatch. It does **not** execute an unverified DSH command. Connect the exact DSH headless runner after following `docs/DSH_SETUP.md`.

## Public repository safety

Anyone can read this repository. Never store:
- API keys or `.env` files
- Android keystore files or passwords
- Personal access tokens
- Private game source/assets you do not intend to publish

Use GitHub Actions secrets for credentials. Public repositories can receive untrusted contributions; workflows use `workflow_dispatch` and read-only permissions by default. Do not run arbitrary pull-request code with secrets.

## Quality gates

A build passing CI only proves that the project imports/exports. It does not prove the game is fun, complete, visually polished, secure, or ready for a store. The production checklist is in `docs/RELEASE_GATES.md`.

## License

Starter text and scripts: MIT. Third-party assets and tools retain their own licenses. See `assets/ASSET_MANIFEST.csv`.
